# Strict Lifestyle Product Prompts

This folder contains all the **unbreakable strict prompts** created for Google Flow / Imagen-style generators.

## How to use
1. Open the `.txt` file for the product you need.
2. Copy the **entire** content.
3. Paste it directly into Google Flow (or similar tool).
4. Attach the original product reference images if the tool allows.
5. Do **not** add any extra words before or after the prompt.

## Rules followed in every prompt
- 1000×1000 square PNG
- Photorealistic lifestyle setting
- Product is the absolute main focus
- Simple elegant home interior
- Real Christmas tree in background with only subtle gold/silver tinsel
- Maximum 2–3 subtle festive accents
- No Shoprite / store branding
- No price tags, extra text, logos (unless part of the actual product)
- No box shots as the hero
- No crowds, multiple faces, or full faces
- No snow or excessive decorations

## Files included
- `00_General_Unbreakable_Template.txt` – Master template
- `01_Christmas_Crackers.txt`
- `02_Santa_Photo_Frame.txt`
- `03_North_Pole_50_Gift_Labels.txt`
- `04_Ultimate_Activity_Books.txt`
- `05_Christmas_Activity_Calendar.txt`
- `06_Luxury_Gift_Tags.txt`
- `07_Navy_Blue_Nutcracker.txt`
- `08_Red_Drummer_Nutcracker.txt`
- `09_Days_Until_Christmas_Nutcracker.txt`
- `10_Circular_Advent_Calendar.txt`
- `11_Green_Foliage_Wreath.txt`

You can upload this entire folder to a new GitHub repository to keep all prompts safely versioned.
